# MayoChat

Discord-inspired real-time chat. Built phase by phase; each phase is deployable and testable on its own.

**Current: Phase 1 (Foundation).** Next.js 15 shell with rail, sidebar, main panel, member panel, notification center, Ctrl+K palette and settings. Appearance and Accessibility settings work and persist locally. Firebase rules are deny-all until a phase needs access.

## Run locally
    npm install
    cp .env.example .env.local   # fill Firebase values
    npm run dev

## Checks
    npm run lint && npm run typecheck && npm run build

## Firebase setup (once)
1. Create a project at console.firebase.google.com (Spark plan is fine).
2. Add a Web app and copy its config into `.env.local`.
3. Enable Authentication (Email/Password, Google), Firestore, Realtime Database, Storage.
4. Deploy rules: `npm i -g firebase-tools && firebase login && firebase use <project-id> && firebase deploy --only firestore:rules,firestore:indexes,database,storage`
   (Storage needs the Blaze plan on new projects; Spark works for everything else.)

## Deploy to an Ubuntu VPS
    sudo apt update && sudo apt install -y nginx git
    curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt install -y nodejs
    sudo npm i -g pm2
    sudo mkdir -p /var/www/mayochat /var/log/mayochat && sudo chown -R $USER /var/www/mayochat /var/log/mayochat
    git clone <your-repo> /var/www/mayochat && cd /var/www/mayochat
    cp .env.example .env.local   # fill values BEFORE building
    ./deploy/deploy.sh
    pm2 startup   # run the command it prints so PM2 survives reboots
    sudo cp deploy/nginx.conf /etc/nginx/sites-available/mayochat   # edit server_name
    sudo ln -s /etc/nginx/sites-available/mayochat /etc/nginx/sites-enabled/ && sudo nginx -t && sudo systemctl reload nginx

Cloudflare: add an A record to the VPS IP (proxied), set SSL/TLS to Full (strict) with an Origin Certificate on Nginx.
In Firebase Auth > Settings > Authorized domains, add your domain (needed from Phase 2).

## Verify Phase 1
- `curl https://your-domain/api/health` returns `{"status":"ok",...,"firebaseConfigured":true}`
- The Home screen's "Firebase connection" card shows green.
- Settings > Appearance changes accent and density and survives a reload.

## Backups
Firebase data: schedule Firestore exports to a Cloud Storage bucket (`gcloud firestore export`). VPS: keep `.env.local` and the service-account key in a private backup; code is in GitHub.

## Structure
`src/{app,components,hooks,lib,services,types,contexts,config,utils}`, `public/{avatars,icons,sounds}`, rules files at the repo root.
