#!/usr/bin/env bash
# Run on the VPS from /var/www/mayochat. NEXT_PUBLIC_* values are baked in at build time,
# so .env.local must exist before this runs.
set -euo pipefail
git pull --ff-only
npm ci
npm run build
# Standalone output needs static assets beside server.js.
cp -r .next/static .next/standalone/.next/static
cp -r public .next/standalone/public
pm2 startOrReload ecosystem.config.cjs --update-env
pm2 save
curl -fsS http://127.0.0.1:3000/api/health && echo " <- healthy"
