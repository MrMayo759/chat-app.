"use client";
import { useState } from "react";
import { Accessibility, Bell, Ban, Link2, Lock, Monitor, Palette, ShieldCheck, User, UserCog } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { Switch } from "@/components/ui/switch";
import { useUI } from "@/contexts/ui-context";
import { cn } from "@/lib/utils";
import type { AccentName, Density } from "@/types";

interface Section { id: string; label: string; icon: LucideIcon; phase?: number }

const SECTIONS: Section[] = [
  { id: "account", label: "My account", icon: User, phase: 2 },
  { id: "profile", label: "Profile", icon: UserCog, phase: 2 },
  { id: "privacy", label: "Privacy and safety", icon: ShieldCheck, phase: 4 },
  { id: "notifications", label: "Notifications", icon: Bell, phase: 6 },
  { id: "appearance", label: "Appearance", icon: Palette },
  { id: "accessibility", label: "Accessibility", icon: Accessibility },
  { id: "blocked", label: "Blocked users", icon: Ban, phase: 4 },
  { id: "connected", label: "Connected accounts", icon: Link2, phase: 2 },
  { id: "sessions", label: "Devices and sessions", icon: Monitor, phase: 2 },
  { id: "security", label: "Security", icon: Lock, phase: 2 },
];

const ACCENTS: { id: AccentName; label: string; color: string }[] = [
  { id: "violet", label: "Violet", color: "#8b6cff" },
  { id: "indigo", label: "Indigo", color: "#6f86ff" },
  { id: "orchid", label: "Orchid", color: "#c26cff" },
  { id: "teal", label: "Teal", color: "#45c2b5" },
];

function Row({ title, hint, children }: { title: string; hint: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-6 py-4">
      <div>
        <p className="text-sm font-medium">{title}</p>
        <p className="mt-0.5 text-[13px] text-muted">{hint}</p>
      </div>
      {children}
    </div>
  );
}

function Appearance() {
  const { appearance, setAppearance } = useUI();
  return (
    <div className="divide-y divide-line">
      <Row title="Accent color" hint="Used for buttons, highlights and your focus ring.">
        <div className="flex gap-2" role="radiogroup" aria-label="Accent color">
          {ACCENTS.map((a) => (
            <button
              key={a.id}
              role="radio"
              aria-checked={appearance.accent === a.id}
              aria-label={a.label}
              onClick={() => setAppearance({ accent: a.id })}
              style={{ backgroundColor: a.color }}
              className={cn("size-7 rounded-full ring-offset-2 ring-offset-panel transition-shadow", appearance.accent === a.id && "ring-2 ring-fg")}
            />
          ))}
        </div>
      </Row>
      <Row title="Density" hint="Compact fits more conversations on screen.">
        <div className="flex rounded-lg bg-base p-0.5">
          {(["comfortable", "compact"] as Density[]).map((d) => (
            <button
              key={d}
              onClick={() => setAppearance({ density: d })}
              className={cn("rounded-md px-3 py-1 text-[13px] capitalize transition-colors", appearance.density === d ? "bg-raised text-fg" : "text-muted hover:text-fg")}
            >
              {d}
            </button>
          ))}
        </div>
      </Row>
      <Row title="Member panel" hint="Show the member list on the right.">
        <Switch label="Show member panel" checked={appearance.showMembers} onChange={(v) => setAppearance({ showMembers: v })} />
      </Row>
    </div>
  );
}

function AccessibilityPane() {
  const { appearance, setAppearance } = useUI();
  return (
    <div className="divide-y divide-line">
      <Row title="Reduce motion" hint="Turns off transitions and animations.">
        <Switch label="Reduce motion" checked={appearance.reduceMotion} onChange={(v) => setAppearance({ reduceMotion: v })} />
      </Row>
    </div>
  );
}

export function SettingsDialog() {
  const { settingsOpen, setSettingsOpen } = useUI();
  const [active, setActive] = useState("appearance");
  const section = SECTIONS.find((s) => s.id === active)!;

  return (
    <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
      <DialogContent className="flex h-[560px] w-[820px] max-w-[94vw] overflow-hidden p-0">
        <DialogDescription className="sr-only">Application settings</DialogDescription>
        <nav aria-label="Settings sections" className="w-56 shrink-0 overflow-y-auto border-r border-line bg-base/40 p-3">
          <p className="px-2.5 pb-2 pt-1 text-xs font-medium text-muted">Settings</p>
          {SECTIONS.map((s) => (
            <button
              key={s.id}
              onClick={() => setActive(s.id)}
              aria-current={active === s.id}
              className={cn("flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[13px] transition-colors", active === s.id ? "bg-accent-soft text-fg" : "text-muted hover:bg-raised hover:text-fg")}
            >
              <s.icon className="size-4" /> {s.label}
            </button>
          ))}
        </nav>
        <section className="flex-1 overflow-y-auto p-8">
          <DialogTitle className="mb-4 text-lg font-semibold">{section.label}</DialogTitle>
          {section.id === "appearance" && <Appearance />}
          {section.id === "accessibility" && <AccessibilityPane />}
          {section.phase && (
            <EmptyState icon={section.icon} title={`${section.label} unlocks in Phase ${section.phase}`} description="This section needs the backend that ships in that phase, so it stays off until it can save for real." />
          )}
        </section>
      </DialogContent>
    </Dialog>
  );
}
