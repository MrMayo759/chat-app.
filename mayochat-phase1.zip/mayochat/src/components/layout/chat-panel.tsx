"use client";
import { PanelRight, Users } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Tip } from "@/components/ui/tooltip";
import { NotificationCenter } from "./notification-center";
import { SetupStatus } from "./setup-status";
import { useUI } from "@/contexts/ui-context";

export function ChatPanel() {
  const { appearance, setAppearance } = useUI();
  return (
    <main className="flex min-w-0 flex-1 flex-col overflow-hidden rounded-xl border border-line bg-panel">
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-line px-4">
        <Users className="size-4 text-muted" />
        <h1 className="text-sm font-semibold">Friends</h1>
        <div className="flex-1" />
        <NotificationCenter />
        <Tip label={appearance.showMembers ? "Hide member panel" : "Show member panel"} side="bottom">
          <Button
            variant="ghost"
            size="icon"
            aria-pressed={appearance.showMembers}
            aria-label="Toggle member panel"
            onClick={() => setAppearance({ showMembers: !appearance.showMembers })}
          >
            <PanelRight />
          </Button>
        </Tip>
      </header>
      <div className="flex-1 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="mx-auto max-w-xl px-6 py-14"
        >
          <h2 className="text-2xl font-semibold tracking-tight">Welcome to MayoChat</h2>
          <p className="mt-2 max-w-md text-[15px] leading-relaxed text-muted">
            The workspace shell is running. Accounts, friends and messaging switch on one phase at a time.
          </p>
          <SetupStatus />
        </motion.div>
      </div>
    </main>
  );
}
