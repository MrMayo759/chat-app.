"use client";
import { useMemo, useState } from "react";
import { PanelRight, Search, Settings } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useUI } from "@/contexts/ui-context";

export function CommandPalette() {
  const { searchOpen, setSearchOpen, setSettingsOpen, appearance, setAppearance } = useUI();
  const [query, setQuery] = useState("");

  const actions = useMemo(
    () => [
      { id: "settings", label: "Open settings", icon: Settings, run: () => setSettingsOpen(true) },
      {
        id: "members",
        label: appearance.showMembers ? "Hide member panel" : "Show member panel",
        icon: PanelRight,
        run: () => setAppearance({ showMembers: !appearance.showMembers }),
      },
    ],
    [appearance.showMembers, setAppearance, setSettingsOpen],
  );
  const results = actions.filter((a) => a.label.toLowerCase().includes(query.trim().toLowerCase()));

  const close = (open: boolean) => {
    setSearchOpen(open);
    if (!open) setQuery("");
  };

  return (
    <Dialog open={searchOpen} onOpenChange={close}>
      <DialogContent className="top-[22%] w-[560px] translate-y-0 p-0">
        <DialogTitle className="sr-only">Search</DialogTitle>
        <DialogDescription className="sr-only">Run an action or search MayoChat</DialogDescription>
        <div className="flex items-center gap-2 border-b border-line px-4">
          <Search className="size-4 text-muted" />
          <Input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search actions"
            className="h-12 border-0 bg-transparent px-0"
          />
        </div>
        <ul className="max-h-72 overflow-y-auto p-2">
          {results.map((a) => (
            <li key={a.id}>
              <button
                type="button"
                onClick={() => { close(false); a.run(); }}
                className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-sm text-fg hover:bg-raised"
              >
                <a.icon className="size-4 text-muted" /> {a.label}
              </button>
            </li>
          ))}
          {results.length === 0 && <li className="px-3 py-6 text-center text-sm text-muted">No actions match “{query}”.</li>}
        </ul>
        <p className="border-t border-line px-4 py-2.5 text-xs text-muted">
          People, servers, channels and messages become searchable in Phases 3 to 5.
        </p>
      </DialogContent>
    </Dialog>
  );
}
