"use client";
import { MessageCircle, Search, Users } from "lucide-react";
import { Wordmark } from "@/components/brand/logo";
import { EmptyState } from "@/components/ui/empty-state";
import { UserPanel } from "./user-panel";
import { useUI } from "@/contexts/ui-context";

export function ChannelSidebar() {
  const { setSearchOpen } = useUI();
  return (
    <aside aria-label="Conversations" className="flex w-[252px] shrink-0 flex-col overflow-hidden rounded-xl border border-line bg-panel">
      <div className="flex h-12 items-center border-b border-line px-4">
        <Wordmark />
      </div>
      <div className="p-2.5">
        <button
          type="button"
          onClick={() => setSearchOpen(true)}
          className="flex h-8 w-full items-center gap-2 rounded-lg bg-base px-2.5 text-left text-[13px] text-muted transition-colors hover:text-fg"
        >
          <Search className="size-3.5" />
          <span className="flex-1">Find or start a chat</span>
          <kbd className="rounded bg-raised px-1.5 py-0.5 text-[10px] font-medium">Ctrl K</kbd>
        </button>
      </div>
      <div className="px-2.5">
        <div
          style={{ height: "var(--mc-row)" }}
          className="flex items-center gap-2.5 rounded-lg bg-accent-soft px-2.5 text-[13px] font-medium text-fg"
        >
          <Users className="size-4 text-accent" /> Friends
        </div>
        <p className="px-2.5 pb-1 pt-4 text-xs font-medium text-muted">Direct messages</p>
      </div>
      <div className="flex-1 overflow-y-auto">
        <EmptyState
          icon={MessageCircle}
          title="No conversations yet"
          description="Chats you start with friends will appear here. Messaging arrives in Phase 3."
        />
      </div>
      <UserPanel />
    </aside>
  );
}
