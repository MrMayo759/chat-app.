"use client";
import { Users } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";

export function MemberPanel() {
  return (
    <aside aria-label="Members" className="flex w-60 shrink-0 flex-col overflow-hidden rounded-xl border border-line bg-panel">
      <div className="flex h-12 items-center border-b border-line px-4 text-sm font-semibold">Members</div>
      <div className="flex-1 overflow-y-auto">
        <EmptyState icon={Users} title="No one here yet" description="Members of a group chat or server are listed here with their status." />
      </div>
    </aside>
  );
}
