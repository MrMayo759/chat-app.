"use client";
import { Compass, Plus, Settings } from "lucide-react";
import { LogoMark } from "@/components/brand/logo";
import { Tip } from "@/components/ui/tooltip";
import { useUI } from "@/contexts/ui-context";
import { cn } from "@/lib/utils";

function RailButton({
  label, children, active, disabled, onClick,
}: { label: string; children: React.ReactNode; active?: boolean; disabled?: boolean; onClick?: () => void }) {
  return (
    <Tip label={label}>
      <button
        type="button"
        aria-label={label}
        aria-disabled={disabled}
        onClick={disabled ? undefined : onClick}
        className={cn(
          "relative flex size-11 items-center justify-center rounded-2xl text-muted transition-all hover:rounded-xl hover:bg-accent-strong hover:text-white",
          active && "rounded-xl bg-accent-strong text-white",
          disabled && "cursor-not-allowed opacity-60 hover:rounded-2xl hover:bg-raised hover:text-muted",
          !active && "bg-raised",
        )}
      >
        {active && <span className="absolute -left-3 h-6 w-1 rounded-r-full bg-fg" />}
        {children}
      </button>
    </Tip>
  );
}

export function ServerRail() {
  const { setSettingsOpen } = useUI();
  return (
    <nav aria-label="Servers" className="flex w-[68px] shrink-0 flex-col items-center gap-2 py-3">
      <RailButton label="Home" active>
        <LogoMark className="size-7" />
      </RailButton>
      <div className="my-1 h-px w-8 bg-line" />
      {/* Server list renders from Firestore membership in Phase 5. */}
      <div className="flex-1" />
      <RailButton label="Create a server (Phase 5)" disabled><Plus className="size-5" /></RailButton>
      <RailButton label="Discover servers (Phase 5)" disabled><Compass className="size-5" /></RailButton>
      <RailButton label="Settings" onClick={() => setSettingsOpen(true)}><Settings className="size-5" /></RailButton>
    </nav>
  );
}
