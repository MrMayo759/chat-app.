"use client";
import { CheckCircle2, CircleDashed } from "lucide-react";
import { firebaseConfigured, missingFirebaseVars } from "@/config/env";

const PHASES = [
  { n: 1, name: "Foundation", done: true },
  { n: 2, name: "Authentication and profiles", done: false },
  { n: 3, name: "Messaging", done: false },
  { n: 4, name: "Friends and presence", done: false },
  { n: 5, name: "Servers and roles", done: false },
  { n: 6, name: "Attachments, notifications, calls", done: false },
  { n: 7, name: "Admin and moderation", done: false },
];

/** Reads the real build-time env so you can confirm Firebase is wired up on your VPS. */
export function SetupStatus() {
  return (
    <div className="mt-8 space-y-4">
      <section className="rounded-xl border border-line bg-base/50 p-4">
        <h3 className="text-sm font-semibold">Firebase connection</h3>
        {firebaseConfigured ? (
          <p className="mt-1.5 flex items-center gap-2 text-[13px] text-success">
            <CheckCircle2 className="size-4" /> All Firebase environment variables are set.
          </p>
        ) : (
          <div className="mt-1.5 text-[13px] text-muted">
            <p className="flex items-center gap-2 text-warning"><CircleDashed className="size-4" /> Missing environment variables:</p>
            <ul className="mt-2 space-y-0.5 pl-6 font-mono text-xs">
              {missingFirebaseVars.map((v) => <li key={v}>{v}</li>)}
            </ul>
            <p className="mt-2">Copy <code className="font-mono">.env.example</code> to <code className="font-mono">.env.local</code>, fill the values, then rebuild.</p>
          </div>
        )}
      </section>
      <section className="rounded-xl border border-line bg-base/50 p-4">
        <h3 className="text-sm font-semibold">Build progress</h3>
        <ul className="mt-2 space-y-1.5">
          {PHASES.map((p) => (
            <li key={p.n} className="flex items-center gap-2 text-[13px]">
              {p.done ? <CheckCircle2 className="size-4 text-success" /> : <CircleDashed className="size-4 text-muted" />}
              <span className={p.done ? "text-fg" : "text-muted"}>Phase {p.n}: {p.name}</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
