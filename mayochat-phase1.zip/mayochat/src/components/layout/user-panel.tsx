"use client";
import { Settings } from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Tip } from "@/components/ui/tooltip";
import { useUI } from "@/contexts/ui-context";

/** Phase 2 replaces the guest identity with the signed-in Firestore profile. */
export function UserPanel() {
  const { setSettingsOpen } = useUI();
  return (
    <div className="flex items-center gap-2.5 border-t border-line bg-base/40 p-2.5">
      <Avatar name="Guest" size={34} />
      <div className="min-w-0 flex-1">
        <p className="truncate text-[13px] font-semibold leading-tight">Guest</p>
        <p className="truncate text-xs text-muted">Sign-in arrives in Phase 2</p>
      </div>
      <Tip label="Settings" side="top">
        <Button variant="ghost" size="icon" aria-label="Open settings" onClick={() => setSettingsOpen(true)}>
          <Settings />
        </Button>
      </Tip>
    </div>
  );
}
