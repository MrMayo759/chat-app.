"use client";
import { TooltipProvider } from "@/components/ui/tooltip";
import { UIProvider, useUI } from "@/contexts/ui-context";
import { ChannelSidebar } from "./channel-sidebar";
import { ChatPanel } from "./chat-panel";
import { CommandPalette } from "./command-palette";
import { MemberPanel } from "./member-panel";
import { ServerRail } from "./server-rail";
import { SettingsDialog } from "./settings-dialog";

function Shell() {
  const { appearance } = useUI();
  return (
    <div className="flex h-screen min-w-[1100px] gap-2 pr-2">
      <ServerRail />
      <div className="flex min-w-0 flex-1 gap-2 py-2">
        <ChannelSidebar />
        <ChatPanel />
        {appearance.showMembers && <MemberPanel />}
      </div>
      <CommandPalette />
      <SettingsDialog />
    </div>
  );
}

export function AppShell() {
  return (
    <UIProvider>
      <TooltipProvider>
        <Shell />
      </TooltipProvider>
    </UIProvider>
  );
}
