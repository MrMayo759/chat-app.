"use client";
import { Bell, CheckCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

/** Items load from Firestore `notifications` in Phase 6; the unread count stays 0 until then. */
export function NotificationCenter() {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" aria-label="Notifications"><Bell /></Button>
      </PopoverTrigger>
      <PopoverContent>
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <h2 className="text-sm font-semibold">Notifications</h2>
          <Button variant="ghost" size="sm" disabled><CheckCheck /> Mark all read</Button>
        </div>
        <EmptyState icon={Bell} title="You're all caught up" description="Friend requests, mentions and invites will show up here." />
      </PopoverContent>
    </Popover>
  );
}
