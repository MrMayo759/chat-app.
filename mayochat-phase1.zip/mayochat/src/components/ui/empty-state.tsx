import type { LucideIcon } from "lucide-react";

export function EmptyState({
  icon: Icon, title, description, children,
}: { icon: LucideIcon; title: string; description: string; children?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center px-6 py-10 text-center">
      <div className="mb-4 flex size-12 items-center justify-center rounded-2xl bg-accent-soft text-accent">
        <Icon className="size-6" />
      </div>
      <h3 className="text-sm font-semibold">{title}</h3>
      <p className="mt-1 max-w-64 text-[13px] leading-relaxed text-muted">{description}</p>
      {children && <div className="mt-4">{children}</div>}
    </div>
  );
}
