import { cn } from "@/lib/utils";

const PALETTE = ["#8b6cff", "#6f86ff", "#c26cff", "#45c2b5", "#e0787f", "#d99a4e"];

export function Avatar({
  name, src, size = 32, className,
}: { name: string; src?: string | null; size?: number; className?: string }) {
  const hue = PALETTE[[...name].reduce((a, c) => a + c.charCodeAt(0), 0) % PALETTE.length];
  const style = { width: size, height: size, fontSize: size * 0.4 };
  if (src) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={src} alt={name} style={style} className={cn("rounded-full object-cover", className)} />;
  }
  return (
    <span
      aria-hidden
      style={{ ...style, backgroundColor: hue }}
      className={cn("inline-flex shrink-0 items-center justify-center rounded-full font-semibold text-white", className)}
    >
      {name.trim().charAt(0).toUpperCase() || "?"}
    </span>
  );
}
