"use client";
import * as React from "react";
import * as T from "@radix-ui/react-tooltip";
import { cn } from "@/lib/utils";

export const TooltipProvider = T.Provider;

export function Tip({
  label, children, side = "right",
}: { label: string; children: React.ReactNode; side?: "top" | "right" | "bottom" | "left" }) {
  return (
    <T.Root delayDuration={150}>
      <T.Trigger asChild>{children}</T.Trigger>
      <T.Portal>
        <T.Content
          side={side}
          sideOffset={10}
          className={cn("z-50 rounded-md border border-line bg-raised px-2.5 py-1.5 text-xs font-medium text-fg shadow-xl")}
        >
          {label}
        </T.Content>
      </T.Portal>
    </T.Root>
  );
}
