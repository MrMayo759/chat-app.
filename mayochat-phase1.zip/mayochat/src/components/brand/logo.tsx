import { cn } from "@/lib/utils";

/** MayoChat mark: a speech bubble whose tail is cut by an "M" of two peaks. */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={cn("size-10", className)} role="img" aria-label="MayoChat">
      <defs>
        <linearGradient id="mc-g" x1="6" y1="4" x2="42" y2="44" gradientUnits="userSpaceOnUse">
          <stop stopColor="var(--mc-accent)" />
          <stop offset="1" stopColor="var(--mc-accent-strong)" />
        </linearGradient>
      </defs>
      <path d="M24 3C12.4 3 4 11 4 21.5c0 5.3 2.2 9.9 5.8 13.1-.3 3.2-1.5 5.7-3.3 7.9 4.2-.2 7.6-1.7 10.1-3.6 2.3.7 4.8 1.1 7.4 1.1 11.6 0 20-8 20-18.5S35.600 3 24 3Z" fill="url(#mc-g)" />
      <path d="M14 29V16.500l10 9.500 10-9.500V29" fill="none" stroke="#fff" strokeWidth="3.600" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return <span className={cn("text-[15px] font-semibold tracking-tight", className)}>MayoChat</span>;
}
