import { getApp, getApps, initializeApp, type FirebaseApp } from "firebase/app";
import { clientEnv } from "@/config/env";

/**
 * Returns the Firebase app, or null when env vars are missing.
 * Phase 1 never requires Firebase; later phases call this and show a setup screen on null.
 */
export function getFirebaseApp(): FirebaseApp | null {
  if (!clientEnv) return null;
  if (getApps().length) return getApp();
  return initializeApp({
    apiKey: clientEnv.NEXT_PUBLIC_FIREBASE_API_KEY,
    authDomain: clientEnv.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
    projectId: clientEnv.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
    storageBucket: clientEnv.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: clientEnv.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
    appId: clientEnv.NEXT_PUBLIC_FIREBASE_APP_ID,
    databaseURL: clientEnv.NEXT_PUBLIC_FIREBASE_DATABASE_URL,
  });
}
