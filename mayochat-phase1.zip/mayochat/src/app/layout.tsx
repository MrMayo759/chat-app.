import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "MayoChat", template: "%s · MayoChat" },
  description: "Real-time chat for friends and communities.",
};
export const viewport: Viewport = { themeColor: "#131316", colorScheme: "dark" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-accent="violet" data-density="comfortable" data-motion="full">
      <body>{children}</body>
    </html>
  );
}
