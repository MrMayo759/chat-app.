import { AppShell } from "@/components/layout/app-shell";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  void children; // Route content mounts inside the shell from Phase 2 onward.
  return <AppShell />;
}
