import { NextResponse } from "next/server";
import { firebaseConfigured, missingFirebaseVars } from "@/config/env";

export const dynamic = "force-dynamic";

export function GET() {
  return NextResponse.json({
    status: "ok",
    app: "mayochat",
    phase: 1,
    firebaseConfigured,
    missingFirebaseVars,
    time: new Date().toISOString(),
  });
}
