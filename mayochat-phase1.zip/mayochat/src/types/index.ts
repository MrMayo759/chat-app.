export type AccentName = "violet" | "indigo" | "orchid" | "teal";
export type Density = "comfortable" | "compact";

export interface AppearanceSettings {
  accent: AccentName;
  density: Density;
  reduceMotion: boolean;
  showMembers: boolean;
}

export const DEFAULT_APPEARANCE: AppearanceSettings = {
  accent: "violet",
  density: "comfortable",
  reduceMotion: false,
  showMembers: true,
};
