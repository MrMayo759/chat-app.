"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { DEFAULT_APPEARANCE, type AppearanceSettings } from "@/types";

const STORAGE_KEY = "mayochat:appearance:v1";

interface UIContextValue {
  appearance: AppearanceSettings;
  setAppearance: (patch: Partial<AppearanceSettings>) => void;
  settingsOpen: boolean;
  setSettingsOpen: (v: boolean) => void;
  searchOpen: boolean;
  setSearchOpen: (v: boolean) => void;
}

const UIContext = createContext<UIContextValue | null>(null);

function load(): AppearanceSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? { ...DEFAULT_APPEARANCE, ...JSON.parse(raw) } : DEFAULT_APPEARANCE;
  } catch {
    return DEFAULT_APPEARANCE;
  }
}

export function UIProvider({ children }: { children: React.ReactNode }) {
  const [appearance, setState] = useState<AppearanceSettings>(DEFAULT_APPEARANCE);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => setState(load()), []);

  useEffect(() => {
    const el = document.documentElement;
    el.dataset.accent = appearance.accent;
    el.dataset.density = appearance.density;
    el.dataset.motion = appearance.reduceMotion ? "reduce" : "full";
  }, [appearance]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const setAppearance = useCallback((patch: Partial<AppearanceSettings>) => {
    setState((prev) => {
      const next = { ...prev, ...patch };
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch { /* storage unavailable */ }
      return next;
    });
  }, []);

  const value = useMemo(
    () => ({ appearance, setAppearance, settingsOpen, setSettingsOpen, searchOpen, setSearchOpen }),
    [appearance, setAppearance, settingsOpen, searchOpen],
  );
  return <UIContext.Provider value={value}>{children}</UIContext.Provider>;
}

export function useUI() {
  const ctx = useContext(UIContext);
  if (!ctx) throw new Error("useUI must be used within UIProvider");
  return ctx;
}
