module.exports = {
  apps: [{
    name: "mayochat",
    cwd: "/var/www/mayochat",
    script: ".next/standalone/server.js",
    env: { NODE_ENV: "production", PORT: 3000, HOSTNAME: "127.0.0.1" },
    max_memory_restart: "500M",
    autorestart: true,
    out_file: "/var/log/mayochat/out.log",
    error_file: "/var/log/mayochat/error.log",
    time: true,
  }],
};
